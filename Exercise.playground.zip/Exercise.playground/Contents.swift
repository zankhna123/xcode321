import UIKit
func goodMorning(){
    print("Good Morning")
}
goodMorning()

func printTotalWithTax(_ subtotal:Double){
    print(subtotal * 1.13)
    }
printTotalWithTax(100)

func getTotalWithTax(_ subtotal:Double) -> Double{
    let x = subtotal * 1.13
    return x
}
var result = getTotalWithTax(200)
print(result)

func calculateTotalWithTax(_ subtotal:Double,_ tax:Double) -> Double{
    let x = subtotal * tax
    return x
}
var ans = calculateTotalWithTax(326,1.15)
print(ans)
//***************************
class Spaceship{
    var fuelLevel  = 50
    var name=""
    func liftOff() {
        fuelLevel -= 50
        print("We have lift off !")
        print("Current Fuel Level at : \(fuelLevel)")
    }
    func addFuel(fuel:Int) {
        fuelLevel += fuel
        print("Fuel Added")
        print("Current Fuel Level at : \(fuelLevel)")
        }
    func cruise() {
        fuelLevel -= 5
        print("Rocket is Cruising")
        print("Current Fuel Level at : \(fuelLevel)")
    }
    func thrust() {
        fuelLevel -= 15
         print("Rocket is thrusting")
         print("Current Fuel Level at : \(fuelLevel)")
    }
    }

var myShip:Spaceship = Spaceship() //initialized object myShip of class Spaceship.
myShip.addFuel(fuel: 50)
myShip.liftOff()
myShip.thrust()
myShip.cruise()
//******************************************
func vowelDetector(str : String) -> Bool {
    var b = false
    
    if str.contains("a") || str.contains("e") || str.contains("i") || str.contains("o") || str.contains("u") {
    b = true
    }
    else {
        b = false
    }
    return b
}
var t = vowelDetector(str: "sync")
print(t)
var f = vowelDetector(str: "hello")
print(f)
